#include "main.h"
#include "AppDelegate.h"
#include "cocos2d.h"

USING_NS_CC;

// �����Ƿ���ʾ����̨��
constexpr bool OPEN_CONSOLE = false;

int WINAPI _tWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR lpCmdLine, int nCmdShow)
{
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

	// ��������̨
	if (OPEN_CONSOLE)
	{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
		AllocConsole();
		freopen("CONIN$", "r", stdin);
		freopen("CONOUT$", "w", stdout);
		freopen("CONOUT$", "w", stderr);
#endif
	}

	// create the application instance
	AppDelegate app;
	auto _ret = Application::getInstance()->run();

	// �ͷſ���̨
	if (OPEN_CONSOLE)
	{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
		FreeConsole();
#endif
	}

	return _ret;
}
