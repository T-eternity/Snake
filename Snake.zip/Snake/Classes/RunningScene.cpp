#include "RunningScene.h"
#include "HomeScene.h"
#include "SimpleAudioEngine.h"

Scene* Running::createScene()
{
	return Running::create();
}

// Print useful error message instead of segfaulting when files are not there
static void problemLoading(const char* filename)
{
	printf("Error while loading: %s\n", filename);
}

// On "init" you need to initialize your instance
bool Running::init()
{
	//////////////////////////////
	// 1. super init first
	if (!Scene::init())
	{
		return false;
	}

	auto visibleSize = Director::getInstance()->getVisibleSize();
	Vec2 origin = Director::getInstance()->getVisibleOrigin();
	ct = GetCurrentTime();		// ��ȡ����¼�� ms Ϊ��λ��ʱ���
	srand((unsigned)time(nullptr));

	//////////////////////////////
	// 2. add your codes below...

	scheduleUpdate();	// ������ʱ��

	// �������̼����������÷�������� WASD �����߷���
	this->listenerKeyboard = EventListenerKeyboard::create();
	this->listenerKeyboard->onKeyPressed = [this](EventKeyboard::KeyCode kcode, Event*)
	{
		switch (kcode)
		{
		case (EventKeyboard::KeyCode::KEY_W):
		case EventKeyboard::KeyCode::KEY_UP_ARROW:
			if (this->getDir() != Direction::DOWN)
			{
				this->setDir(Direction::UP);
				snakeNodes.front()->setRotation(0);
			}
			toUpdata = true;
			break;

		case (EventKeyboard::KeyCode::KEY_A):
		case EventKeyboard::KeyCode::KEY_LEFT_ARROW:
			if (this->getDir() != Direction::RIGHT)
			{
				this->setDir(Direction::LEFT);
				snakeNodes.front()->setRotation(270);
			}
			toUpdata = true;
			break;

		case (EventKeyboard::KeyCode::KEY_S):
		case EventKeyboard::KeyCode::KEY_DOWN_ARROW:
			if (this->getDir() != Direction::UP)
			{
				this->setDir(Direction::DOWN);
				snakeNodes.front()->setRotation(180);
			}
			toUpdata = true;
			break;

		case (EventKeyboard::KeyCode::KEY_D):
		case EventKeyboard::KeyCode::KEY_RIGHT_ARROW:
			if (this->getDir() != Direction::LEFT)
			{
				this->setDir(Direction::RIGHT);
				snakeNodes.front()->setRotation(90);
			}
			toUpdata = true;
			break;

		default:
			break;
		}
	};
	_eventDispatcher->addEventListenerWithSceneGraphPriority(this->listenerKeyboard, this);

	// ���澫��
	SpriteFrameCache::getInstance()->addSpriteFrame(SpriteFrame::create("Head.png", Rect(0, 0, 20, 20)), "Head");
	SpriteFrameCache::getInstance()->addSpriteFrame(SpriteFrame::create("Node.png", Rect(0, 0, 20, 20)), "Node");
	SpriteFrameCache::getInstance()->addSpriteFrame(SpriteFrame::create("Wall.png", Rect(0, 0, 20, 20)), "Wall");

	// ���û���֡����ǽ
	for (int j = 0; j < this->cols; ++j)
	{
		Map[0][j] = Map[this->rows - 1][j] = true;
		auto wall1 = Sprite::createWithSpriteFrameName("Wall");
		auto wall2 = Sprite::createWithSpriteFrameName("Wall");
		wall1->setPosition(Running::convertToGL(Vec2(0, j)));
		wall2->setPosition(Running::convertToGL(Vec2(this->rows - 1, j)));
		this->addChild(wall1, -2);
		this->addChild(wall2, -2);
	}
	for (int i = 1; i < this->rows - 1; ++i)
	{
		Map[i][0] = Map[i][this->cols - 1] = true;
		auto wall1 = Sprite::createWithSpriteFrameName("Wall");
		auto wall2 = Sprite::createWithSpriteFrameName("Wall");
		wall1->setPosition(Running::convertToGL(Vec2(i, 0)));
		wall2->setPosition(Running::convertToGL(Vec2(i, this->cols - 1)));
		this->addChild(wall1, -2);
		this->addChild(wall2, -2);
	}

	// ������ˢ��ʳ��
	food = Sprite::create("Food.png");
	newFood();
	this->addChild(food, -1);

	// ���û���֡�����߽ڵ�����߽ڵ�����
	auto spriteHead = Sprite::createWithSpriteFrameName("Head");
	Vec2 nodePos;
	nodePos = Vec2(this->rows / 2, this->cols / 2);
	spriteHead->setPosition(Running::convertToGL(nodePos));
	spriteHead->setRotation(90);	// ��ʼ����ͷ��������
	snakeNodes.push_back(spriteHead);
	this->addChild(spriteHead, 1);
	Map[(int)nodePos.x][(int)nodePos.y] = true;
	for (int k = 0; k < 2; ++k)
	{
		nodePos.x -= 1;
		auto spriteNode = Sprite::createWithSpriteFrameName("Node");
		spriteNode->setPosition(Running::convertToGL(nodePos));
		snakeNodes.push_back(spriteNode);
		this->addChild(spriteNode, 0);
		Map[(int)nodePos.x][(int)nodePos.y] = true;
	}

	auto labelScore = Label::createWithSystemFont("Score: 0", "΢���ź�", 20);
	labelScore->setPosition(20 + labelScore->getContentSize().width / 2, visibleSize.height - 20 - labelScore->getContentSize().height / 2);
	this->addChild(labelScore, 2, 111);

	return true;
}

void Running::update(float dt)
{
	if (toUpdata) toUpdata = false;
	// ���ٶ����߽ڵ㳤�����Ӷ����
	else if (GetCurrentTime() - ct < 160 - (2 * (snakeNodes.size() - 3) > 130 ? 130 : 2 * (snakeNodes.size() - 3))) return;

	ct = GetCurrentTime();	// ˢ�¼�¼��ʱ��

	auto visibleSize = Director::getInstance()->getVisibleSize();
	Vec2 origin = Director::getInstance()->getVisibleOrigin();

	auto head = snakeNodes.front();		// ��¼�ƶ�ǰͷλ��
	auto posHead = Running::convertToMap(head->getPosition());

	Vec2 dxy(0, 0);
	if (dir == Direction::UP) dxy.y = 1;
	else if (dir == Direction::DOWN) dxy.y = -1;
	else if (dir == Direction::LEFT) dxy.x = -1;
	else dxy.x = 1;

	// �Ե�ʳ����ӽڵ�
	if (Vec2(posHead.x + dxy.x, posHead.y + dxy.y) == Running::convertToMap(food->getPosition()))
	{
		auto spriteNode = Sprite::createWithSpriteFrameName("Node");
		spriteNode->setPosition(Running::convertToGL(posHead));
		snakeNodes.insert(++snakeNodes.begin(), spriteNode);
		this->addChild(spriteNode, 0);

		// ˢ�µ÷�
		char str[128]{ 0 };
		sprintf_s(str, "Score: %d", snakeNodes.size() - 3);
		auto labelScore = Label::createWithSystemFont(str, "΢���ź�", 20);
		static_cast<Label*>(this->getChildByTag(111))->setString(str);

		newFood();
	}
	// δ�Ե�ʳ��
	else
	{
		auto back = snakeNodes.back();
		auto posBack = Running::convertToMap(back->getPosition());
		Map[int(posBack.x)][int(posBack.y)] = false;
		back->setPosition(Running::convertToGL(posHead));
		snakeNodes.pop_back();
		snakeNodes.insert(++snakeNodes.begin(), back);
	}
	// ײ��ǽ�����Լ�����ʱ����Ϸ����
	if (Map[int(posHead.x + dxy.x)][int(posHead.y + dxy.y)] == true)
	{
		unscheduleUpdate();		// ֹͣ��ʱ��
		_eventDispatcher->removeEventListener(this->listenerKeyboard);	// �Ƴ�������
		auto gameover = Sprite::create("GameOver.png");
		gameover->setPosition(origin.x + visibleSize.width / 2, origin.x + visibleSize.height / 2 + 40);
		this->addChild(gameover, 2);

		// �����˵���ѡ�񷵻ػ������¿�ʼ
		// �����ص���ҳ��ť
		auto homeItem = MenuItemImage::create("BackNormal.png", "BackSelected.png", CC_CALLBACK_1(Running::menuCallbackToHome, this));
		homeItem->setPosition(origin.x + visibleSize.width / 2 - 50, origin.x + visibleSize.height / 2 - 40);
		// �������¿�ʼ�˵�
		auto goItem = MenuItemImage::create("GoonNormal.png", "GoonSelected.png", CC_CALLBACK_1(Running::menuCallbackRestart, this));
		goItem->setPosition(origin.x + visibleSize.width / 2 + 50, origin.x + visibleSize.height / 2 - 40);
		// Create menu, it's an autorelease object
		auto menuClose = Menu::create(homeItem, goItem, NULL);
		menuClose->setPosition(Vec2::ZERO);
		this->addChild(menuClose, 2);
	}

	// ˢ��ͷ�ڵ�λ��
	head->setPosition(Running::convertToGL(Vec2(posHead.x + dxy.x, posHead.y + dxy.y)));
	Map[int(posHead.x + dxy.x)][int(posHead.y + dxy.y)] = true;
}

void Running::menuCallbackToHome(cocos2d::Ref* pSender)
{
	SpriteFrameCache::getInstance()->removeSpriteFrames();	// ��ջ���
	Director::getInstance()->replaceScene(Home::createScene());
}

void Running::menuCallbackRestart(cocos2d::Ref* pSender)
{
	Director::getInstance()->replaceScene(Running::createScene());
}

// ˢ��ʳ��λ�ã����Ż�
void Running::newFood()
{
	if (snakeNodes.size() >= (rows - 1) * (cols - 1) - 1)
	{
		food->runAction(Hide::create());
		food->setPosition(999, 999);
		return;
	}
	Vec2 nodePos;
	do
	{
		nodePos.x = rand() % (this->rows - 2) + 1;
		nodePos.y = rand() % (this->cols - 2) + 1;
	} while (Map[(int)nodePos.x][(int)nodePos.y] == true);
	food->setPosition(Running::convertToGL(nodePos));
}
